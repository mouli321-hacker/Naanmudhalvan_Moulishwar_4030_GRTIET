from django.shortcuts import render
from .models import Song

def home(request):
    songs = Song.objects.all()
    return render(request, 'home.html', {'songs': songs})
