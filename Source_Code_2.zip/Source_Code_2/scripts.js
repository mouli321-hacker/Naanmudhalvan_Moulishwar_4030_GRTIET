// JavaScript code for handling song click event
document.addEventListener("DOMContentLoaded", function() {
    // Get all song elements
    var songs = document.querySelectorAll(".song");

    // Add click event listener to each song
    songs.forEach(function(song) {
        song.addEventListener("click", function() {
            // Get the title of the clicked song
            var title = song.querySelector("h3").textContent;
            
            // Display a message with the title of the clicked song
            alert("You clicked on: " + title);
        });
    });
});
